<?php

defined ('BASEPATH') OR exi('No direct script access allowed');
class User extends CI_Controller {


  
 
public function __construct(){
 
        parent::__construct();
        
        $this->load->model('User_model');

        
        $this->load->database();
        
 
}
 
public function load_login()
{
$this->load->view('login');



}

public function patient_info(){
  $this->load->view('patientInfo.php');

}

public function doctor_dashboard(){

  
  $this->load->view('doclanding.php');
}

 
public function load_register()
{
$this->load->view('register');

if($this->input->post('register')){

  $data=array
           (
             'user_name'=>$this->input->post('user_name'),
             'user_email'=>$this->input->post('user_email'),
             'user_password'=>md5($this->input->post('user_name')),
             'user_age'=>$this->input->post('user_age'),
             'user_mobile'=>$this->input->post('user_mobile'),

           );



    //print_r($data);

    $this->User_model->saverecords($data['user_name'],$data['user_email'],$data['user_password'],$data['user_age'],$data['user_mobile']);    
    echo "Records Saved Successfully";


}






}
function index()
{
  $data['allpat']=$this->User_model->getpat();
  $this->load->view('pat_view',$data);
}
function get_pat_result()
{
  $parData =$this->input->post('patData');
  if(isset($patData)and !empty($patData))
  {
    $records = $this->User_model->get_pat($patData);
    $output='';
    foreach ($records->result_array() as $row) {

      $output ='
      <h4 class="text-center"->'.$row["patname"].'</h4>
      <div class="row">
      <div class="col-lg-6">
      <table class = "table table-bordered">
      <tr>
            <td><b>sname</b></td>
            <td>'.$row["sname"].'</td>
           </tr>
           <tr>
            <td><b>fname</b></td>
            <td>'.$row["fname"].'</td>            
           </tr>
           </table>
           </div>
           </div>';


    }
    echo $output;
  }
  
}




}

?>


