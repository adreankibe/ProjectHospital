<?php

class User_model extends CI_model{
 
 
 function saverecords($name,$email,$password,$age,$mobile)
  {
  $query="insert into user values(' ','$name','$email','$password','$age','$mobile')";
  $insert=$this->db->query($query);
  }
 
public function register_user($user){
 
 
$this->db->insert('user', $user);
 
}
 
public function login_user(){
 //$email,$pass
  $this->db->select('*');
  $this->db->from('user');
 // $this->db->where('user_email',$email);
 // $this->db->where('user_password',$pass);
 
  if($query=$this->db->get())
  {
      return $query->result_array();
  }
  else{
    return false;
  }
 
 
}
public function email_check($email){
 
  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_email',$email);
  $query=$this->db->get();
 
  if($query->num_rows()>0){
    return false;
  }else{
    return true;
  }
 
}
function getpat()
{
  $this->db->select('*');
  $this->db->order_by('patno','DESC');
  $query=$this->db->get('pat');
  return $query->result();


}
function get_pat($patdata)
{
  $this->db->select('*');
  $this->db->where('patno',$patdata);
  $res2=$this->get('pat');
  return $res2;
}
 
}
 
 
?>